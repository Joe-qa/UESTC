#include "ServerTcp.h"
#include <iostream>
#include <unistd.h>

int main(int argc, char* argv[]){
    std::cout<<"server tcp -> instruction description"<<std::endl;
    std::cout<<"\tq -> exit"<<std::endl;
    std::cout<<"\tr -> deserialization the other server's data"<<std::endl;
    ServerTcp tcp(argv[1], atoi(argv[2]), atoi(argv[3]));
    tcp.start();
    while(true){
        char ch = std::cin.get();
        if(ch == 'q'){
            break;
        }
        else if(ch == 'r'){
            tcp.deserialization();
        }
        usleep(100);
    }
    tcp.stop();
    tcp.serialize();
    return 0;
}