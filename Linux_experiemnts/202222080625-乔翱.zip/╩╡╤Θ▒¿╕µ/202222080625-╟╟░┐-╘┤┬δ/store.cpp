#include <iostream>
#include "Account.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <memory.h>
#include <unistd.h>
#include <fstream>

std::string get_word(std::string& s);

int main(int argc, char* argv[]){
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd == -1){
        std::cout<<"client tcp -> create socket failed"<<std::endl;
        return 0;	
	}
    struct sockaddr_in addr;                          
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr=inet_addr(argv[1]);
    addr.sin_port = htons(atoi(argv[2]));
    socklen_t len = sizeof(addr);
    if(connect(fd ,(struct sockaddr*)&addr ,len) == -1){
        std::cout<<"client tcp -> connect server failed"<<std::endl;
        return 0;
    }
    else{
        std::cout<<"client tcp -> connect server success"<<std::endl;
    }
    std::cout<<"client tcp -> instruction description"<<std::endl;
    std::cout<<"\tlist -> get goods list from server"<<std::endl;
    std::cout<<"\tadd {name} {price} -> add a good to server"<<std::endl;
    std::cout<<"\tdel {name} -> delete a good from server"<<std::endl;
    std::cout<<"\tq -> exit"<<std::endl;
    while(true){
        std::cout<<"please input command: ";
        char cmd[1024];
        std::cin.getline(cmd, 1024);
        write(fd, cmd, 1024);
        std::string s(cmd);
        std::string word = get_word(s);
        if(word == "list"){
            read(fd, cmd, 1024);
            usleep(200);
            int size = atoi(cmd);
            std::cout<<"client tcp -> there are "<<size<<" goods"<<std::endl;
            for(int i = 0; i < size; i++){
                 read(fd, cmd, 1024);
                 std::string t(cmd);
                 std::string name = get_word(t);
                 t.erase(t.begin(), t.begin() + name.size() + 1);
                 std::string price = get_word(t);
                 std::cout<<"\tname:"<<name<<", price:"<<price<<std::endl;
                 usleep(200);
            }
        }
        else if(word == "add"){
            //do nothing
        }
        else if(word == "del"){
            //do nothing
        }
        else if(word == "q"){
            break;
        }
        usleep(50);
    }
    close(fd);
    return 0;
}

std::string get_word(std::string& s){
    if(s == ""){
        return "";
    }
    int j = 0;
    for(int i = 0; i < s.size(); i++){
        if(s[i] == ' '){
            j = i;
            break;
        }
    }
    if(j == 0){
        return s;
    }
    std::string word = s.substr(0, j);
    return word;
}