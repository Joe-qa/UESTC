#ifndef _ACCOUNT_H
#include <vector>
#include "Good.h"

class Account{
public:
    std::string id;
    std::vector<Good> goods;
};

#endif