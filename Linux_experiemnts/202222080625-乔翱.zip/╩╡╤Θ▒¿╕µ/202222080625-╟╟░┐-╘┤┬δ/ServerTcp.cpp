#include <iostream>
#include "ServerTcp.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <memory.h>
#include <unistd.h>
#include <fstream>

ServerTcp* gTcpServer = NULL;

typedef struct SockInfo{
    int fd;
    struct sockaddr_in addr;
}SockInfo;

ServerTcp::ServerTcp(std::string ip, int port, int len_of_queue_of_listen){
    this->ip = ip;
    this->port = port;
    this->len_of_queue_of_listen = len_of_queue_of_listen;
    run_flag = false;
    stop_flag = false;
    pthread_mutex_init(&stop_mutex, NULL);
    pthread_mutex_init(&run_mutex, NULL);
    gTcpServer = this;
    menu.push_back(Good{"water", 2.00, 0});
    menu.push_back(Good{"drink", 6.00, 0});
}

ServerTcp::~ServerTcp(){
    pthread_mutex_lock(&stop_mutex);
    stop_flag = true;
    pthread_mutex_unlock(&stop_mutex);
    while(true){
        pthread_mutex_lock(&run_mutex);
        bool temp = run_flag;
        pthread_mutex_unlock(&run_mutex);
        if(!temp){
            break;
        }
        usleep(50);
    }
    pthread_mutex_destroy(&stop_mutex);
    pthread_mutex_destroy(&run_mutex);
}

void ServerTcp::start(){
    if(run_flag){
        return;
    }
    run_flag = true;
    if(pthread_create(&pth_listen, NULL, listen_func, static_cast<void*>(this)) != 0){
        std::cout<<"server tcp -> create thread for listening failed"<<std::endl;
    }
    else{
        std::cout<<"server tcp -> create thread for listening success"<<std::endl;
    }
}

void ServerTcp::stop(){
    pthread_mutex_lock(&stop_mutex);
    stop_flag = true;
    pthread_mutex_unlock(&stop_mutex);
}

void* ServerTcp::listen_func(void* arg){
    ServerTcp* p = (ServerTcp*)arg;
    int sockfd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);
	if (sockfd == -1){
        std::cout<<"server tcp -> create socket failed"<<std::endl;
        return NULL;	
	}
    struct sockaddr_in serveraddr;
	memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(p->port);
	serveraddr.sin_addr.s_addr = inet_addr(p->ip.c_str());
	if (bind(sockfd, (struct sockaddr*)(&serveraddr), sizeof(serveraddr)) < 0)  {
        std::cout<<"server tcp -> bind socket failed"<<std::endl;
		return NULL;
	}
    else{
        std::cout<<"server tcp -> bind socket success"<<std::endl;
    }
    int ret = listen(sockfd, p->len_of_queue_of_listen);
 	if(ret == -1){
        std::cout<<"server tcp -> start listen failed"<<std::endl;
        return NULL;
    }
    else{
        std::cout<<"server tcp -> start listen success"<<std::endl;
    }
    pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    while(true){
        struct sockaddr_in clientaddr;
        socklen_t len = sizeof(clientaddr);
		int fd = accept(sockfd, (struct sockaddr*) &clientaddr, &len);
		if (fd >= 0){
            SockInfo info{fd, clientaddr};
			pthread_t th;
		    if (pthread_create(&th, &attr, client_func, static_cast<void*>(&info)) != 0){
			    std::cout<<"server tcp -> create thread for incoming failed"<<std::endl;
		    }
            else{
                std::cout<<"server tcp -> create thread for incoming success"<<std::endl;
            }
		}
		pthread_attr_destroy(&attr);
        pthread_mutex_lock(&p->stop_mutex);
        bool stop_flag = p->stop_flag;
        pthread_mutex_unlock(&p->stop_mutex);
        if(stop_flag){
            pthread_mutex_lock(&p->run_mutex);
            p->run_flag = false;
            pthread_mutex_unlock(&p->run_mutex);
            std::cout<<"server tcp -> stop server"<<std::endl;
            break;
        }
        usleep(50);
    }
    return NULL;
}

std::string ServerTcp::get_word(std::string& s){
    if(s == ""){
        return "";
    }
    int j = 0;
    for(int i = 0; i < s.size(); i++){
        if(s[i] == ' '){
            j = i;
            break;
        }
    }
    if(j == 0){
        return s;
    }
    std::string word = s.substr(0, j);
    return word;
}

void* ServerTcp::client_func(void* arg){
    SockInfo* pInfo = (SockInfo*)(arg);
    char ip[20];
    inet_ntop(AF_INET, &pInfo->addr.sin_addr.s_addr, ip, sizeof(ip));
    int port = ntohs(pInfo->addr.sin_port);
    std::cout<<"server tcp -> client{"<<ip<<", "<<port<<"} connected"<<std::endl;
    std::vector<Good> picks;
    while(true){
        char recv[1024];
        int len = read(pInfo->fd, &recv, 1024);
        if(len == -1){
            std::cout<<"server tcp -> client{"<<ip<<", "<<port<<"} recv error"<<std::endl;
        }
        else if(len > 0){
            std::cout<<"server tcp -> client{"<<ip<<", "<<port<<"} recv data: "<<recv<<std::endl;
            std::string recvBuf(recv);
            std::string cmd = get_word(recvBuf);
            if(cmd == "add"){
                recvBuf.erase(recvBuf.begin(), recvBuf.begin() + cmd.size() + 1);
                std::string name = get_word(recvBuf);
                recvBuf.erase(recvBuf.begin(), recvBuf.begin() + name.size() + 1);
                std::string price = get_word(recvBuf);
                recvBuf.erase(recvBuf.begin(), recvBuf.begin() + price.size());
                gTcpServer->add_good(Good{name, atof(price.c_str()), 0});
                std::cout<<"server tcp -> client{"<<ip<<", "<<port<<"} add good finish"<<std::endl;
            }
            else if(cmd == "del"){
                recvBuf.erase(recvBuf.begin(), recvBuf.begin() + cmd.size() + 1);
                std::string name = get_word(recvBuf);
                recvBuf.erase(recvBuf.begin(), recvBuf.begin() + name.size());
                gTcpServer->del_good(name);
                std::cout<<"server tcp -> client{"<<ip<<", "<<port<<"} delete good finish"<<std::endl;
            }
            else if(cmd == "list"){
                recvBuf.erase(recvBuf.begin(), recvBuf.begin() + cmd.size());
                char sendBuf[1024] = "";
                sprintf(sendBuf, "%ld", gTcpServer->menu.size());
                write(pInfo->fd, sendBuf, 1024);
                usleep(200);
                for(int i = 0; i < gTcpServer->menu.size(); i++){
                    sprintf(sendBuf, "%s %.2lf", gTcpServer->menu[i].name.c_str(), gTcpServer->menu[i].price);
                    write(pInfo->fd, sendBuf, 1024);
                    usleep(200);
                }
            }
            else if(cmd == "pick"){
                recvBuf.erase(recvBuf.begin(), recvBuf.begin() + cmd.size() + 1);
                std::string name = get_word(recvBuf);
                recvBuf.erase(recvBuf.begin(), recvBuf.begin() + name.size() + 1);
                std::string amount = get_word(recvBuf);
                recvBuf.erase(recvBuf.begin(), recvBuf.begin() + amount.size());
                picks.push_back(Good{name, 0.0, atoi(amount.c_str())});
            }
            else if(cmd == "pay"){
                double sum = 0.0;
                for(int i = 0; i < picks.size(); i++){
                    int j = 0;
                    for(;j < gTcpServer->menu.size();j++){
                        if(picks[i].name == gTcpServer->menu[j].name){
                            break;
                        }
                    }
                    if(j < gTcpServer->menu.size()){
                        sum += gTcpServer->menu[j].price * picks[i].amount;
                    }
                }
                char sendBuf[1024] = "";
                sprintf(sendBuf, "you should pay %.2lf", sum);
                write(pInfo->fd, sendBuf, 1024);
                picks.clear();
            }
        }
        else if(len == 0){
            std::cout<<"server tcp -> client{"<<ip<<", "<<port<<"} closed"<<std::endl;
            break;
        }
    }
    return NULL;
}

void ServerTcp::add_good(Good good){
    for(int i = 0; i < menu.size(); i++){
        if(menu[i].name == good.name){
            return;
        }
    }
    menu.push_back(good);
}

void ServerTcp::del_good(std::string name){
    for(int i = 0; i < menu.size(); i++){
        if(menu[i].name == name){
            menu.erase(menu.begin() + i);
            return;
        }
    }
}

void ServerTcp::serialize(){
    std::ofstream out("server.data", std::ios::binary);
    if(!out.is_open()){
        std::cout<<"server tcp -> create server.data failed"<<std::endl;
        return;
    }
    int size = menu.size();
    out.write((char*)&size, sizeof(int));
    for(int i = 0; i < menu.size(); i++){
        char name[100] = "";
        sprintf(name, "%s", menu[i].name.c_str());
        out.write(name, 100);
        double price = menu[i].price;
        out.write((char*)&price, sizeof(double));
    }
    out.close();
    std::cout<<"server tcp -> serialize success"<<std::endl;
}

void ServerTcp::deserialization(){
    std::ifstream in("server.data", std::ios::binary);
    if(!in.is_open()){
        std::cout<<"server tcp -> open server.data failed"<<std::endl;
        return;
    }
    int size;
    in.read((char*)&size, sizeof(int));
    for(int i = 0; i < size; i++){
        char name[100] = "";
        in.read(name, 100);
        double price;
        in.read((char*)&price, sizeof(double));
        add_good(Good{name, price, 0});
    }
    in.close();
    std::cout<<"server tcp -> deserialization success"<<std::endl;
}