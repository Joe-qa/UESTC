#ifndef _GOOD_H
#include <string>

class Good{
public:
    std::string name;
    double price;
    int amount;
};

#endif