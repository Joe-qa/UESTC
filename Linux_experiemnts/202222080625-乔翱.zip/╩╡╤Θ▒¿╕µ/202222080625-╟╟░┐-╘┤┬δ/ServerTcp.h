#include <string>
#include <pthread.h>
#include <unordered_map>
#include "Account.h"

class ServerTcp{

public:
    ServerTcp(std::string ip, int port, int len_of_queue_of_listen);
    ~ServerTcp();
    void start();
    void stop();
    static void* listen_func(void* arg);
    static void* client_func(void* arg);
    static std::string get_word(std::string& s);
    void add_good(Good good);
    void del_good(std::string name);
    void serialize();
    void deserialization();
private:
    std::string ip;
    int port;
    int len_of_queue_of_listen;
    pthread_t pth_listen;
    bool run_flag;
    bool stop_flag;
    pthread_mutex_t stop_mutex;
    pthread_mutex_t run_mutex;
    std::vector<Good> menu;
};