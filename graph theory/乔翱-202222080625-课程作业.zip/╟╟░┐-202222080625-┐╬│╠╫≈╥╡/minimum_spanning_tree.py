#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：乔翱-202222080625-课程作业
@File    ：minimum_spanning_tree.py
@IDE     ：PyCharm
@Author  ：qiao ao
@Date    ：2023/5/21 16:54
"""

import matplotlib.pyplot as plt
import networkx as nx


# 边结构，两个点u和v以及这条边的权重w
class Edge:
    def __init__(self, u, v, w):
        self.u = u
        self.v = v
        self.w = w


class Graph:
    def __init__(self, n, m):
        self.n = n
        self.m = m
        self.e = []
        self.G = nx.Graph()
        self.T = nx.Graph()
        self.min_weight = 0

    # 接收控制台输入的边的信息，构建图G
    def input_graph(self):
        for i in range(self.m):
            u, v, w = list(map(int, input().split()))
            self.e.append(Edge(u, v, w))
        # 遍历输入的边构建图G
        self.G.add_weighted_edges_from(((edge.u, edge.v, edge.w) for edge in iter(self.e)))

    # 画出图G
    def draw_graph(self):
        nx.draw(self.G, pos=nx.circular_layout(self.G), with_labels=True, alpha=0.9)
        labels = nx.get_edge_attributes(self.G, 'weight')
        nx.draw_networkx_edge_labels(self.G, pos=nx.circular_layout(self.G), edge_labels=labels, font_color='r',font_size=20)
        nx.draw_networkx_edges(self.G, pos=nx.circular_layout(self.G), edgelist=self.T.edges, edge_color='g', width=1)
        # 保存图片
        plt.savefig("minimum_spanning_tree.png", bbox_inches="tight")
        # 显示图片
        plt.show()

    # 输出最小生成树
    def output_graph(self):
        # 输出最小生成树的节点
        print(self.T.nodes)
        # 输出最小生成树的边
        print(sorted(self.T.edges(data=True)))
        # 输出最小生成树的总权重
        print("the weight of minimum_spanning_tree is ", self.min_weight)

    def run(self):
        # 计算得出最小生成树T
        self.T = nx.minimum_spanning_tree(self.G)
        # 计算最小生成树的总权重
        for u, v, w in self.T.edges(data=True):
            self.min_weight += w['weight']


def main():
    # 输入节点数和边数
    n, m = list(map(int, input().split()))
    # 初始化图G
    G = Graph(n, m)
    # 根据输入的边构建图G
    G.input_graph()
    # 计算得出最小生成树T
    G.run()
    # 输出最小生成树
    G.output_graph()
    # 画出图G和最小生成树
    G.draw_graph()


# 主程序入口
if __name__ == '__main__':
    main()
