#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：乔翱-202222080625-课程作业 
@File    ：prime.py
@IDE     ：PyCharm 
@Author  ：qiao ao
@Date    ：2023/5/20 15:34 
"""


class Edge:
    def __init__(self, x, y, weight):
        self.x = x
        self.y = y
        self.weight = weight


class Node:
    def __init__(self, node, weight):
        self.node = node
        self.weight = weight


class Graph:
    def __init__(self, n, m):
        self.n = n
        self.m = m
        # 邻接表
        self.v = [[] for i in range(n + 1)]
        self.e = []
        # min_tree 存储最小生成树
        self.min_tree = []
        # visited记录节点是否被访问过
        self.visited = [False for i in range(n + 1)]

    # 初始化图，使用邻接表存图
    def initGraph(self):
        for i in range(self.m):
            x, y, weight = list(map(int, input().split()))
            self.v[x].append(Node(y, weight))
            self.v[y].append(Node(x, weight))

    # 加入一个节点到最小生成树中
    def add_mintree(self, vertex):
        for i in range(len(self.v[vertex])):
            # 把与vertex连接的且未被visit的点的边加入e
            if not self.visited[self.v[vertex][i].node]:
                self.e.append(Edge(vertex, self.v[vertex][i].node, self.v[vertex][i].weight))
        # 按从小到大排序e中的边，方便之后从小到大遍历边
        self.e = sorted(self.e, key=lambda e: e.weight)
        self.visited[vertex] = True

    # 使用prim算法计算最小生成树
    def prim(self):
        # 从节点1开始，随意插入一个节点都可以，可以从任意节点开始计算最小生成树
        self.add_mintree(1)
        # 最小生成树的边数是图中节点数减1，所以当找到的最小生成树边数为图中节点数减一的时候跳出循环
        while self.n - len(self.min_tree) > 1:
            for i in range(len(self.e)):
                # 如果这条边的另一个顶点未被访问过，则说明这条边可以被加入最小生成树中
                if not self.visited[self.e[i].y]:
                    self.min_tree.append(self.e[i])
                    self.add_mintree(self.e[i].y)
                    break

    def output(self):
        min_weight = 0
        for i in range(len(self.min_tree)):
            print(f'u: {self.min_tree[i].x}, v: {self.min_tree[i].y}, weight: {self.min_tree[i].weight}')
            min_weight += self.min_tree[i].weight
        print(f'the weight of minimum_spanning_tree is {min_weight}')


# 主程序入口
def main():
    n, m = list(map(int, input().split()))
    G = Graph(n, m)
    G.initGraph()
    G.prim()
    G.output()


if __name__ == '__main__':
    main()
