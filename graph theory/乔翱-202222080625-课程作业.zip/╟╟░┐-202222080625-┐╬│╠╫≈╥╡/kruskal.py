#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：乔翱-202222080625-课程作业 
@File    ：kruskal.py
@IDE     ：PyCharm 
@Author  ：qiao ao
@Date    ：2023/5/20 16:04 
"""


class Edge:
    def __init__(self, x, y, weight):
        self.x = x
        self.y = y
        self.weight = weight


# 并查集，用来判断图中所有节点是否连通
class UnionFindSet:
    def __init__(self, start, n):
        self.start = start
        self.n = n
        self.pre = [0 for i in range(self.n - self.start + 2)]
        self.rank = [0 for i in range(self.n - self.start + 2)]

    def init(self):
        for i in range(self.start, self.n + 1):
            self.pre[i] = i
            self.rank[i] = 1

    def find_pre(self, x):
        if self.pre[x] == x:
            return x
        else:
            self.pre[x] = self.find_pre(self.pre[x])
        return self.pre[x]

    def is_same(self, x, y):
        return self.find_pre(x) == self.find_pre(y)

    # 判断顶点x和y是否连通
    def unite(self, x, y):
        x = self.find_pre(x)
        y = self.find_pre(y)
        if x == y:
            return False
        if self.rank[x] > self.rank[y]:
            self.pre[y] = x
        else:
            if self.rank[x] == self.rank[y]:
                self.rank[y] += 1
            self.pre[x] = y
        return True

    # 判断图所有节点是否连通
    def is_one(self):
        temp = self.find_pre(self.start)
        for i in range(self.start + 1, self.n + 1):
            if self.find_pre(i) != temp:
                return False
        return True


class Graph:
    def __init__(self, n, m):
        self.n = n
        self.m = m
        self.e = []
        self.min_tree = []
        # 并查集，用来判断图的连通
        self.u = UnionFindSet(1, self.n)

    def initGraph(self):
        for i in range(self.m):
            x, y, weight = list(map(int, input().split()))
            self.e.append(Edge(x, y, weight))
        self.e.sort(key=lambda e: e.weight)
        self.u.init()

    # 使用kruskal算法计算最小生成树
    def kruskal(self):
        for i in range(self.m):
            if self.u.unite(self.e[i].x, self.e[i].y):
                self.min_tree.append(self.e[i])
            # 如果连通分支为1，说明得到了最小生成树
            if self.u.is_one():
                break

    def output(self):
        min_weight = 0
        for i in range(len(self.min_tree)):
            print(f'u: {self.min_tree[i].x}, v: {self.min_tree[i].y}, weight: {self.min_tree[i].weight}')
            min_weight += self.min_tree[i].weight
        print(f'the weight of minimum_spanning_tree is {min_weight}')


# 主程序入口
def main():
    n, m = list(map(int, input().split()))
    G = Graph(n, m)
    G.initGraph()
    G.kruskal()
    G.output()


if __name__ == '__main__':
    main()
